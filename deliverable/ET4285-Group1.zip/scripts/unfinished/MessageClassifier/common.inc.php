<?php
$link = new mysqli('localhost','twitchtoxicity','HQELvGGlP5csVJHffmH5','twitchtoxicity');
?>